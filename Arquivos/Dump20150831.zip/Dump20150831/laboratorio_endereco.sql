CREATE DATABASE  IF NOT EXISTS `laboratorio` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `laboratorio`;
-- MySQL dump 10.13  Distrib 5.5.44, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: laboratorio
-- ------------------------------------------------------
-- Server version	5.5.44-0+deb8u1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `endereco`
--

DROP TABLE IF EXISTS `endereco`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `endereco` (
  `idEndereco` int(11) NOT NULL AUTO_INCREMENT,
  `logradouro` varchar(45) DEFAULT NULL,
  `numero` varchar(45) DEFAULT NULL,
  `bairro` varchar(45) DEFAULT NULL,
  `cep` varchar(45) DEFAULT NULL,
  `cidade` varchar(45) DEFAULT NULL,
  `UF` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idEndereco`)
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `endereco`
--

LOCK TABLES `endereco` WRITE;
/*!40000 ALTER TABLE `endereco` DISABLE KEYS */;
INSERT INTO `endereco` VALUES (1,'rua a','1','centro','36500000','uba','mg'),(2,'logradouro','numero','bairro','cep','cidade','uf'),(3,'logradouro','numero','bairro','cep','cidade','uf'),(4,'logradouro','numero','bairro','cep','cidade','uf'),(5,'logradouro','numero','bairro','cep','cidade','uf'),(7,'logradouro','numero','bairro','cep','cidade','uf'),(9,'logradouro','numero','bairro','cep','cidade','uf'),(10,'logradouro','numero','bairro','cep','cidade','uf'),(11,'logradouro','numero','bairro','cep','cidade','uf'),(12,'Rua a','23','centro',NULL,'uba','mg'),(13,'Rua a','23','centro',NULL,'uba','mg'),(14,NULL,NULL,NULL,NULL,NULL,NULL),(15,NULL,NULL,NULL,NULL,NULL,NULL),(16,NULL,NULL,NULL,NULL,NULL,NULL),(17,NULL,NULL,NULL,NULL,NULL,NULL),(18,'rua a','12','centro','123456','sinop','mt'),(19,'rua a','12','centro','123456','sinop','mt'),(20,NULL,NULL,NULL,NULL,NULL,NULL),(21,'rua b','11','eldorado','36500000','ubÃ¡','mg'),(22,'rua b','11','eldorado','36500000','ubÃ¡','mg'),(23,NULL,NULL,NULL,NULL,NULL,NULL),(24,NULL,NULL,NULL,NULL,NULL,NULL),(25,NULL,NULL,NULL,NULL,NULL,NULL),(26,NULL,NULL,NULL,NULL,NULL,NULL),(27,NULL,NULL,NULL,NULL,'1',NULL),(28,'1','1','1',NULL,'1',NULL),(29,'q','','',NULL,'',NULL),(30,'','22','',NULL,'',NULL),(31,'','','sss',NULL,'',NULL),(32,'','','',NULL,'xxxxx',NULL),(33,'','','',NULL,'',NULL),(34,'','','',NULL,'','ssss'),(35,'1','1','1',NULL,'1','1'),(36,'1','1','1',NULL,'1','1'),(37,'','','','11','',''),(38,'1','1','1','1','1','1'),(39,'','','','','',''),(40,'','','','','',''),(41,'','','','','',''),(42,'','','','','',''),(43,'','','','','',''),(44,'','','','','',''),(45,'1','1','1','1','1','1'),(46,'1','1','1','1','1','1'),(47,'1','1','1','1','1','1'),(48,'1','1','1','1','1','1'),(49,'1','1','1','1','1','1'),(50,'1','1','1','1','1','1'),(51,'1','1','1','1','1','1'),(53,'1','1','1','1','1','1'),(55,'1','1','1','1','1','1'),(57,'1','1','1','1','1','1'),(59,'1','1','1','1','1','1'),(61,'1','1','1','1','1','1'),(63,'1','1','11','1','1','1'),(65,'rua1','1','bairro','cep','cidade','uf'),(67,'rua1','1','bairro','cep','cidade','uf'),(69,'rua1','1','bairro','cep','cidade','uf'),(71,'rua1','1','bairro','cep','cidade','uf'),(72,'rua1','1','bairro','cep','cidade','uf'),(73,'rua1','1','bairro','cep','cidade','uf'),(74,'rua1','1','bairro','cep','cidade','uf'),(75,'rua1','1','bairro','cep','cidade','uf'),(76,'rua1','1','bairro','cep','cidade','uf'),(77,'rua1','1','bairro','cep','cidade','uf'),(78,'rua1','1','bairro','cep','cidade','uf'),(79,'rua1','1','bairro','cep','cidade','uf'),(81,'rua1','1','bairro','cep','cidade','uf'),(83,'rua1','1','bairro','cep','cidade','uf'),(85,'rua1','1','bairro','cep','cidade','uf'),(87,'rua1','1','bairro','cep','cidade','uf'),(89,'rua1','1','bairro','cep','cidade','uf'),(91,'1','1','1','1','1','1'),(92,NULL,NULL,NULL,NULL,NULL,NULL),(93,NULL,NULL,NULL,NULL,NULL,NULL),(94,'rua 2','8','vit','88','juiz de fora','mg'),(95,NULL,NULL,NULL,NULL,NULL,NULL),(96,'u','8','u','8','u','u');
/*!40000 ALTER TABLE `endereco` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-08-31 17:50:59
